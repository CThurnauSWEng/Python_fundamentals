def maxMinAvg(arr): 
    max=arr[0]
    min=arr[0]
    avg=0 
    sum=0 
    for val in arr: 
        if val > max:
            max = val
        elif val < min:
            min = val
        sum += val
    avg = sum/len(arr)
    print "max: ",max
    print "min: ",min
    print "avg: ",avg
    print "sum: ",sum
    print "len: ",len(arr)

arr = [3,4,5,6,5,4,3]
maxMinAvg(arr)
def outputNames(students):
    '''
    outputs the first and last names for each person in the given list
    '''

    name = ""
    for element in students:
        name = element["first_name"] + " " + element["last_name"]
        print name


students = [
     {'first_name':  'Michael', 'last_name' : 'Jordan'},
     {'first_name' : 'John', 'last_name' : 'Rosales'},
     {'first_name' : 'Mark', 'last_name' : 'Guillen'},
     {'first_name' : 'KB', 'last_name' : 'Tonel'}
]

outputNames(students)

# part 2

def outputNames2(users):
    '''
    outputs names of the students, then the names of the instructors
    '''
    fullName = ""
    grouplen = 0

    for group in users:
        print group
        grouplen = len(users[group])
        for person in range (0,grouplen):
            fullName =  users[group][person]["first_name"] + " " + users[group][person]["last_name"]
            print str(person+1) + " - " + fullName + " " + str(len(fullName)-1)



users = {
 'Students': [
     {'first_name':  'Michael', 'last_name' : 'Jordan'},
     {'first_name' : 'John', 'last_name' : 'Rosales'},
     {'first_name' : 'Mark', 'last_name' : 'Guillen'},
     {'first_name' : 'KB', 'last_name' : 'Tonel'}
  ],
 'Instructors': [
     {'first_name' : 'Michael', 'last_name' : 'Choi'},
     {'first_name' : 'Martin', 'last_name' : 'Puryear'}
  ]
}

outputNames2(users)


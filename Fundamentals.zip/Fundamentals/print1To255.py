for count in range(1,256):
    print count
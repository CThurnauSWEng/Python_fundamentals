def greaterThanY(arr,y): 
    count=0
    for val in arr: 
        if val > y:
            count+= 1
    print count 
newarr = [2,4,6,7,8,9]
greaterThanY(newarr,5)

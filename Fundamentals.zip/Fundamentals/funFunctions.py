def oddEven():
  for i in range(1,200):  #yes, I'm purposefully using 200 instead of 2000 :)
    if (i % 2 == 0):
      print "Number is ",i," This is an even number"
    else:
      print "Number is ",i," This is an odd number"
  return 1

print "****** Odd/Even *********"
oddEven()


def multiply(list,factor):
  newList = list
  for i in range(0,len(list)):
    newList[i] = list[i] * factor
  return newList

print "******* Multiply ********"
a = [2,4,10,16]
b = multiply(a,5)
print b

print "********* Hacker Challenge ************"
# Write a function that takes the multiply function call as an argument. 
# Your new function should return the multiplied list as a two-dimensional list. 
# Each internal list should contain the 1's times the number in the original list. 
# Here's an example:

#Note to self - this is where I left off

def layered_multiples(arr):
  # first element in new_array will contain arr[0] number of ones

  lenArr = len(arr)
  new_array = []
  for i in range (0,lenArr):
    sub_array = []
    for j in range (0,arr[i]):
      sub_array.append(1)
    
    new_array.append(sub_array)

  return new_array
x = layered_multiples(multiply([2,4,5],3))
# hint: ask yourself what will the multiply function return? That is what 
# will get passed to layered multiples.
# for this case, multiply will return the array [6,12,15]
print x
# output
# >>>[[1,1,1,1,1,1],[1,1,1,1,1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]]

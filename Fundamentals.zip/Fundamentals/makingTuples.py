def makeTuple(dict):
    '''
    Takes in a dictionary and returns a tuple
    '''

    # for the sample input:
    # key is Speros...etc.
    # dict[key] is (555) 555-555...etc.


    newArr = []
    
    for key in dict:
        print key
        print dict[key]
        myTuple = (key,dict[key])
        newArr.append(myTuple)


    return newArr


# function input
my_dict = {
  "Speros": "(555) 555-5555",
  "Michael": "(999) 999-9999",
  "Jay": "(777) 777-7777"
}

print makeTuple(my_dict)

#function output
#[("Speros", "(555) 555-5555"), ("Michael", "(999) 999-9999"), ("Jay", "(777) 777-7777")]
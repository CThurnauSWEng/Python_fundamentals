def scoresGrades():
    '''
    Randomly generates 10 scores between 60 and 100 and assigns 
    grades based on the score
    '''

    # get a random score
    import random
    score = random.randint(60,100)

    grade = ''
    #convert score to grade
    if (score >=  90):
        grade = 'A'
    elif (score >= 80):
        grade = 'B'
    elif (score >= 70):
        grade = 'C'
    else:
        grade = 'D'
    
    print "Score: ", score, "; Your grade is: ",grade

print "Scores and Grades"
for i in range(0,10):
    scoresGrades()

print "End of the program. Bye!"
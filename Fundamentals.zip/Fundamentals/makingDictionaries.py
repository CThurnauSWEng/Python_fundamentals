def makingDictionaries(list1,list2):
    '''
    This function takes in two lists and creates and returns a
    single dictionary
    If lists are different lengths, use longer list for keys and
    shorter list for values
    '''

    new_dict = {}
    lenList1 = len(list1)
    lenList2 = len(list2)
    temp = []

    if lenList2 > lenList1:     #swap them
        temp = list1
        list1 = list2
        list2 = temp


    idx = 0
    print "list1: ",list1
    print "list2: ",list2

    for element in list1:
        print "key: ", element
        print "value: ", list2[idx]
        new_dict[element] = list2[idx]
        if idx < lenList2-1:                #ran out of values, keep using the last one
            idx += 1
    

    return new_dict


name = ["Anna", "Eli", "Pariece", "Brendan", "Amy", "Shane", "Oscar"]
favorite_animal = ["horse", "cat", "spider", "giraffe", "ticks", "dolphins", "llamas"]

print makingDictionaries(name,favorite_animal)

favorite_animal2 = ["horse", "cat"]
print makingDictionaries(name,favorite_animal2)


myStr = 'x  1   2   3   4   5   6   7   8   9   10  11  12'
print myStr

for count in range (1,13):
  myStr = str(count) + " "
  if (count < 10):
    myStr += " "

  for multiplier in range (1,13):
    result = count * multiplier
    myStr += str(result) + " "
    if (result < 10):
      myStr += " "
    if (result < 100):
      myStr += " "

  print myStr
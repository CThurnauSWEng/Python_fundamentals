x = "Hello Python"
print x
y = 42
print y

# commenting a single line
# we can even comment out code
# print "this will not print!"

print "read below for more on multi-line comments in python!" #this would execute
# This line and below would not execute
'''
Triple quotations allow us to comment across multiple lines as long as
the triple quoted comment is not the first thing in your file.
You can use double or single quotes!
'''
print "done commenting"

# define a function that says hello to the name provided
# this starts a new block
def say_hello(name):
  #these lines are indented therefore part of the function
  if name:
   print 'Hello, ' + name + 'from inside the function'
  else:
   print 'No name'
# now we're unindented and have ended the previous block
print 'Outside of the function'

name = "Zen"
print "My name is", name

name1 = "Carrie"
motto = "Concat"
print "My name is " + name1 + motto
print "notice no space when I did 'name1 + motto'"

name2 = "Kaylee"
age = 4
print "using ',': ", name2,age
# print "using '+'" + name2 + age => error msg 'cannot concatenate str and int

first_name = "Zen"
last_name = "Coder"
print "My name is {} {}".format(first_name, last_name)

#deprecated method:

hw = "hello %s" % 'world'
print hw
# the output would be:
# hello world

x = "Hello World"
print x.upper()

#commonly used string methods:
'''
The following is a list of commonly used string methods:
string.count(substring): returns number of occurrences of substring in string.
string.endswith(substring): returns a boolean based upon whether the last characters of string match substring.
string.find(substring): returns the index of the start of the first occurrence of substring within string.
string.isalnum(): returns boolean depending on whether the string's length is > 0 and all characters are alphanumeric (letters and numbers only). Strings that include spaces and punctuation will return False for this method. Similar methods include .isalpha(), .isdigit(), .islower(), .isupper(), and so on. All return booleans.
string.join(list): returns a string that is all strings within our set (in this case a list) concatenated.
string.split(): returns a list of values where string is split at the given character. Without a parameter the default split is at every space.
'''

fruits = ['apple','banana','orange','strawberry']
print "fruits"
print fruits
print "***"
vegetables = ['lettuce','cucumber','carrots']
print "vegetables"
print vegetables
print "***"



fruits_and_vegetables = fruits + vegetables
print "fruits_and_vegetables"
print fruits_and_vegetables
print "***"
salad = 3 * vegetables
print "3 * vegetables"
print salad
print "***"

drawer = ['documents', 'envelopes', 'pens']
#access the drawer with index of 0 and print value
print drawer[0]  #prints documents
#access the drawer with index of 1 and print value
print drawer[1] #prints envelopes
#access the drawer with index of 2 and print value
print drawer[2] #prints pens

x = [1,2,3,4,5]
x.append(99)
print x

x = [99,4,2,5,-3]
print "x is now:"
print x
print "***"

print "x[:]"
print x[:]
#the output would be [99,4,2,5,-3]
print "***"

print "x[1:]"
print x[1:]
#the output would be [4,2,5,-3];
print "***"

print "x[:4]"
print x[:4]
#the output would be [99,4,2,5]
print "***"

print "x[2:4]"
print x[2:4]
#the output would be [2,5];
print "***"

#len() is like 'length in javascript
my_list = [1, 'Zen', 'hi']
print len(my_list)

'''
Some built-in functions for sequences:
enumerate(sequence) used in a for loop context to return 
two-item-tuple for each item in the list indicating the index 
followed by the value at that index.
map(function, sequence) applies the function to every item in the 
sequence you pass in. Returns a list of the results.
min(sequence) returns the lowest value in a sequence.
sorted(sequence) returns a sorted sequence
There are a few other useful built-in functions. Find them here.


The following are some commonly used list methods:
list.extend(list2) adds all values from a second sequence to the 
end of the original sequence.
list.pop(index) remove a value at given position. if no
 parameter is passed, defaults to final value in the list.
list.index(value) returns the index position in a list for the 
given parameter.


A tuple is a sequence of immutable Python objects. Tuples are 
sequences, just like lists. The differences between tuples and 
lists are, the tuples cannot be changed unlike lists and tuples use 
parentheses, whereas lists use square brackets. Creating 
a tuple is as simple as putting different comma-separated values.
'''

if age >= 18:
  print 'Legal age'
elif age == 17:
  print 'You are seventeen.'
else:
  print 'You are so young!'

for count in range(0, 5):
  print "looping = ", count

my_list = [4, 'dog', 99, ['list','inside','another'], 'hello world!']
print 'my_list: ',my_list
print '***'
print 'now print each element from a for loop'
for element in my_list:
  print element

count = 0
while count < 5:
  print 'looping -', count
  count += 1

#break and continue are like javascript
for val in "string":
  if val == "i":
    break
  print val

for val in "string":
  if val == "i":
    continue
  print val

# else in while statement...

x = 3
y = x
while y > 0:
  print y
  y = y - 1
else:
  print "Final else statement"

# the else does not happen if a break has occurred

x = 3
y = x
while y > 0:
  print y
  y = y - 1
  if y == 0:
    break
else:
 print "Final else statement"

# tuples

tuple_data = ('physics', 'chemistry', 1997, 2000)
tuple_num = (1, 2, 3, 4, 5 )
tuple_letters = "a", "b", "c", "d"

print "tuple_data",tuple_data
print "tuple_num",tuple_num
print "tuple_letters",tuple_letters

dog = ("Canis Familiaris", "dog", "carnivore", 12)
print "dog: ",dog
print "dog[2]: ",dog[2]

for data in dog:
  print "data: ", data

dog = dog + ("domestic",)
print "dog: ",dog
#result is...
#("Canis Familiaris", "Dog", "carnivore", 12, "domestic")

# can slice tuples

dog = dog[:3] + ("man's best friend",) + dog[4:]
#result is...
#("Canis Familiaris", "Dog", "carnivore", "man's best friend", "domestic")

# You may recognize some of these built-in functions for sequences:
# max(sequence) returns the largest value in the sequence
# sum(sequence) return the sum of all values in sequence
# enumerate(sequence) used in a for-loop context to return two-item-tuple for 
#     each item in the sequence indicating the index followed by the value at that index.
# map(function, sequence) applies the function to every item in the sequence you 
#     pass in. Returns a list of the results.
# min(sequence) returns the lowest value in a sequence.
# sorted(sequence) returns a sorted sequence

#dictionary

weekend = {"Sun": "Sunday", "Sat": "Saturday"} #literal notation
capitals = {} #create an empty dictionary then add values
capitals["svk"] = "Bratislava"
capitals["deu"] = "Berlin"
capitals["dnk"] = "Copenhagen"

#to print all keys
for data in capitals:
     print data
#another way to print all keys
for key in capitals.iterkeys():
     print key
#to print the values
for val in capitals.itervalues():
     print val
#to print all keys and values
for key,data in capitals.iteritems():
     print key, " = ", data

# Python includes the following standalone functions for dictionaries:

# cmp(dict1, dict2) - Compares two dictionaries. The comparison process starts 
#  with the length of each dictionary, followed by key names, followed by values. 
#  The function returns 0 if the two dicts are equal, -1 if dict1 > dict2, 
#  1 if dict1 < dict2.
# len() - give the total length of the dictionary.
# str() - produces a string representation of a dictionary.
# type() - returns the type of the passed variable. If passed variable is a 
#   dictionary, it will then return a dictionary type.
# Python includes the following dictionary methods:
# (either dict.method(yourDictionary) or yourDictionary.method() will work)

# .clear() - removes all elements from the dictionary
# .copy() - returns a shallow copy dictionary
# .fromkeys(sequence, [value] ) - create a new dictionary with keys from sequence 
#    and values set to value.
# .get(key, default=None) - For key key, returns value or default if key is not in 
#     dictionary.
# .has_key(key) - returns true if a given key is available in the dictionary, otherwise 
#   it returns false.
# .items() - returns a list of dictionary's (key, value) tuple pairs.
# .keys() - return a list of dictionary keys.
# .setdefault(key, default=None) - similar to get(), but will set dict[key]=default 
#    if key is not already in dictionary.
# .update(dict2) = adds dictionary dict2's key-values pairs to an existing dictionary.
# .values() - returns list of dictionary values.

data ={"house":"Haus","cat":"Katze","red":"rot"}
print data.items()
#[('house', 'Haus'), ('red', 'rot'), ('cat', 'Katze')]
print data.keys()
#['house', 'red', 'cat']
print data.values()
#['Haus', 'rot', 'Katze']

#making a dictionary from lists:

dishes = ["pizza", "sauerkraut", "paella", "hamburger"]
countries = ["Italy", "Germany", "Spain", "USA"]

country_specialities = zip(countries, dishes)
print country_specialities
#Result is...
#[('Italy', 'pizza'), ('Germany', 'sauerkraut'), ('Spain', 'paella'), ('USA', 'hamburger')]

country_specialities_dict = dict(country_specialities)
print country_specialities_dict
#Result is...
#{'Germany': 'sauerkraut', 'Spain': 'paella', 'Italy': 'pizza', 'USA': 'hamburger'}



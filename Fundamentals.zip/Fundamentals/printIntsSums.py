sum = 0

for count in range(0,256):
    print "count: ",count
    sum += count
    print "sum: ",sum
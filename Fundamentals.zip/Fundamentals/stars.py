def draw_stars(arr):
    '''
    For each number provided in the passed list parameter, draw_stars
    prints a line with that many number of stars (i.e. '*') on the line
    '''

    for num in arr:
        myStr = ""
        for count in range(0,num):
            myStr += '*'
        print myStr

x =  [4, 6, 1, 3, 5, 7, 25]
print x
draw_stars(x)

def draw_stars2(arr):
    '''
    This version accepts either strings or integers in the passed list.
    If a list element is a number, it prints that many stars.
    If a list element is a string, it prints the first character in the string.
    '''

    for element in arr:
        if type(element) == int:
            myStr = ""
            for count in range(0,element):
                myStr += '*'
            print myStr
        elif type(element) == str:
            myStr = ""
            for count in range(0,len(element)):
                myStr += element[0]
            print myStr.lower()
        else:
            print "unsupported element type: ",element
            return 0
    
    return 1

x = [4, "Tom", 1, "Michael", 5, 7, "Jimmy Smith"]
print x
draw_stars2(x)

for count in range(0, 8):
  if (count % 2 == 0):
    print "* * * * "
  else:
    print " * * * * "
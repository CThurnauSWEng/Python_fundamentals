# print odd numbers from 1 to 1000
for count in range(1, 1000, 2):
  print "looping = ", count

# print multiples of 5 from 5 to 1,000,000 (note using 5,000 to make it easire to check)
for count in range(5, 5000, 5):
    print "more looping: ", count

sum = 0
a = [1, 2, 5, 10, 255, 3]
print "a:",a
for val in a:
    sum += val

print "sum of values in a: ",sum

avg = sum/len(a)

print "average of values in a:",avg
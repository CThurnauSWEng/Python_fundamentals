def compareLists(list1, list2):
  print "Comparing list1: "
  print list1
  print "and list2:"
  print list2
  list1len = len(list1)
  list2len = len(list2)

  if (list1len != list2len):
    # Lists have different lengths
    return 0
  
  for index in range (list1len):
    if (list1[index] != list2[index]):
      return 0

  return 1

# test it

list_one = [1,2,5,6,2]
list_two = [1,2,5,6,2]
if (compareLists(list_one,list_two)):
  print "Lists are identical"
else:
  print "Lists are not identical"
      
list_one = [1,2,5,6,5]
list_two = [1,2,5,6,5,3]
if (compareLists(list_one,list_two)):
  print "Lists are identical"
else:
  print "Lists are not identical"
      
list_one = [1,2,5,6,5,16]
list_two = [1,2,5,6,5]
if (compareLists(list_one,list_two)):
  print "Lists are identical"
else:
  print "Lists are not identical"

list_one = [1,3,5,6,5]
list_two = [1,2,5,6,5]
if (compareLists(list_one,list_two)):
  print "Lists are identical"
else:
  print "Lists are not identical"

list_one = ['celery','carrots','bread','milk']
list_two = ['celery','carrots','bread','cream']
if (compareLists(list_one,list_two)):
  print "Lists are identical"
else:
  print "Lists are not identical"

list_one = ['celery','carrots','bread','cream']
list_two = ['celery','carrots','bread','cream']
if (compareLists(list_one,list_two)):
  print "Lists are identical"
else:
  print "Lists are not identical"





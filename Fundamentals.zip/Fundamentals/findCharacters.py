def findCharacters(list1,list2):
  print "list1",list1
  print "list2",list2
  newList = []
  for i in range (len(list1)):
    foundIdx = list1[i].find(list2)
    if (foundIdx >= 0):
      newList.append(list1[i])
  return newList


word_list = ['hello','world','my','name','is','Anna']
char = 'o'
newList = findCharacters(word_list,char)
print "newList: ",newList

char = 'a'
newList = findCharacters(word_list,char)
print "newList: ",newList


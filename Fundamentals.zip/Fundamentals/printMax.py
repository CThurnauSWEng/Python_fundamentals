arr = [4,5,3,99,4,0]
print arr

max = arr[0]

for val in arr:
    if (val > max):
        max = val

print "max: ",max
def analyzeByType(arr):
  print "**********************************"
  print "processing: ",arr
  numElements = len(arr)
  numInts = 0
  numStrs = 0
  numFloats = 0

  sum = 0
  fullStr = ""

  if (numElements == 0):
      print "The list you entered is empty"
      return 0

  for element in arr:
    if type(element) == int:
      numInts += 1
      sum += element
    elif type(element) == str:
      numStrs += 1
      fullStr += element + " "
    elif type(element) == float:
      numFloats += 1
      sum += element
    else:
      print "unimplemented type",element

  if (numInts == numElements):
    print "The list you entered is all ints"
    print "Sum: ",sum
  elif (numStrs == numElements):
    print "The list you entered is all strings"
    print "String: ",fullStr
  elif (numFloats == numElements):
    print "The list you entered is all floats"
    print "Sum: ",sum
  else:
    printStr = "The list your entered is of mixed types: "
    if (numInts):
      printStr += " Ints "
    if (numFloats):
      printStr += " Floats"
    if (numStrs):
      printStr += " Strings"
      printStr += '\n'+"String: "+fullStr
    if (numInts | numFloats):
      printStr += '\n'+"Sum: "+str(sum)
    print printStr
  
  return 1

# test it
arr1 = ['magical unicorns',19,'hello',98.98,'world']
arr2 = [2,3,1,7,4,12]
arr3 = ['magical','unicorns']
arr4 = [0,0]
arr5 = []
arr6 = [1.1, 2.2, 3.3]
arr7 = [1.1, 3.3, 10]
arr8 = [9999]
arr9 = [0]
analyzeByType(arr1)
analyzeByType(arr2)
analyzeByType(arr3)
analyzeByType(arr4)
analyzeByType(arr5)
analyzeByType(arr6)
analyzeByType(arr7)
analyzeByType(arr8)
analyzeByType(arr9)


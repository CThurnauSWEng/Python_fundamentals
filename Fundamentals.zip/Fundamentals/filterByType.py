sI = 45
mI = 100
bI = 455
eI = 0
spI = -23

sS = "Rubber baby buggy bumpers"
mS = "Experience is simply the name we give our mistakes"
bS = "Tell me and I forget. Teach me and I remember. Involve me and I learn."
eS = ""

aL = [1,7,4,21]
mL = [3,5,7,34,3,2,113,65,8,89]
lL = [4,34,22,68,9,13,3,5,7,9,2,12,45,923]
eL = []
spL = ['name','address','phone number','social security number']

def filterByType(a):
  print "**********************************"
  print "processing: ",a
  if type(a) == int:
    if a >= 100:
      print "That's a big integer"
    else:
      print "That's a small integer"
  elif type(a) == str:
    print "str len: ",len(a)
    if len(a) > 50:
      print "Long sentence"
    else:
      print "Short sentence"
  elif type(a) == list:
    print "list len: ", len(a)
    if len(a) > 10:
      print "Big list!"
    else:
      print "Short list!"
  return 1

filterByType(sI)
filterByType(mI)
filterByType(bI)
filterByType(eI)
filterByType(spI)
filterByType(sS)
filterByType(mS)
filterByType(bS)
filterByType(eS)
filterByType(aL)
filterByType(mL)
filterByType(lL)
filterByType(eL)
filterByType(spL)



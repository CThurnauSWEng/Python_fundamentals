def introduction(person):
    print "My name is ",person["Name"]
    print "My age is ",person["Age"]
    print "My country of birth is ",person["BirthCountry"]
    print "My favorite language is ",person["FavLang"]

carrie = {"Name"        :"Carrie",
          "Age"         : 99,
          "BirthCountry":"USA",
          "FavLang"     : "Javascript"}

introduction(carrie)
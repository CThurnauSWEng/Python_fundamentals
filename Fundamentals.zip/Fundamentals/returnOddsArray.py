def returnOddsArray():
    newarr = []
    for val in range(1,256): 
        if val %2 == 1:
            newarr.append(val)
    return newarr
    
arr= returnOddsArray()
print arr

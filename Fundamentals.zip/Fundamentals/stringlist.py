words = "It's Thanksgiving day. It's my birthday, too!"
print words

print "print the position of the first instance of the word 'day'. "

index = words.find("day")
print "index",index

print "words[18]",words[18]

print "Create a new string where the word 'day' is replaces with the word 'month'"
newWords = words.replace("day","month")

print newWords

print "Print the min and max values in a string"
x = [2,54,-2,7,12,98]
print "x",x

min = min(x)
max = max(x)

print "max",max
print "min",min

x = ["hello",2,54,-2,7,12,98,"world"]

print "x",x
print "x[0]",x[0]

xLen = len(x)

print "last element in x:",x[xLen-1]

print x[0],x[xLen-1]

x = [19,2,54,-2,7,12,98,32,10,-3,6]
print "x",x
sortedX = sorted(x)

print "sortedX",sortedX

xLen = len(sortedX)

firstHalf = sortedX[0:xLen/2]
print "firstHalf of sorted x:",firstHalf

secondHalf = sortedX[xLen/2:xLen]
print "secondHalf of sorted x:",secondHalf
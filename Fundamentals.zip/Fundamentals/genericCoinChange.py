def genericCoinChange(legend,amt):

    print "legend passed to function: ",legend


    return countLegend

legend = {  triangle    : 3,
            square      : 7,
            rectangle   : 10}

print genericCoinChange(legend,83)
def coinTosses():
    '''
    This function simulates tossing a coin 5,000 times. It prints
    how many times the head/tail appears.
    '''
    import random
    headCount = 0
    tailCount = 0
    str1 = ""

    for i in range(5001):
        str1 = "Attempt #"+str(i)+": Throwing a coin..."

        random_num = round(random.random())
        # returns a random float between 0.0 and 1.0
        # round this and convert to integer - will be 0 or 1

        if (random_num):            # random_num = 1
            headCount += 1
            str1 += "It's a head!..."
        else:
            tailCount += 1
            str1 += "It's a tail!..."

        str1 += "Got " + str(headCount)+ " head(s) so far and " + str(tailCount)+ " tail(s) so far"
        print str1
    return 1

coinTosses()